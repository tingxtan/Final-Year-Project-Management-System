package myfypms;

import java.sql.Connection;

public class AppointmentDB {
      public static Connection cn;
        AppointmentDB(){
        ConnectDB connectdb = new ConnectDB();
    }
}
