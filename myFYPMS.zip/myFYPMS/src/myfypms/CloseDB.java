package myfypms;
import javax.swing.JOptionPane;

public class CloseDB {
   CloseDB(){
      try{
            AppointmentDB.cn.close();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }  
    }
}
