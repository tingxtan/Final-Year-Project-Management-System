package myfypms;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class ConnectDB {
    ConnectDB()
    {
        try{
           AppointmentDB.cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Database?zeroDateTimeBehavior=convertToNull","root","");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }
}
