package myfypms;
import myfypms.Login;

public class MyFYPMS {

    public static void main(String[] args) {
         new Login().setVisible(true);
    }
    
}

